
## 11.3 Deploying a Scikit-Learn model with KServe

<a href="https://www.youtube.com/watch?v=8kBIDggLwgE&list=PL3MmuxUbc_hIhxl5Ji8t4O6lPAOpHaCLR"><img src="images/thumbnail-11-03.jpg"></a>
 




## Notes

Add notes from the video (PRs are welcome)


<table>
   <tr>
      <td>⚠️</td>
      <td>
         The notes are written by the community. <br>
         If you see an error here, please create a PR with a fix.
      </td>
   </tr>
</table>


## Navigation

* [Machine Learning Zoomcamp course](../)
* [Session 11: KServe](./)
* Previous: [Running KServe locally](02-kserve-local.md)
* Next: [Deploying custom Scikit-Learn images with KServe](04-kserve-custom-image.md)