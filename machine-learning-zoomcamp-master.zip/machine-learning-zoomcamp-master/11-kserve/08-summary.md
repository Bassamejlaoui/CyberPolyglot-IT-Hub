
## 11.8 Summary

Coming soon (or not so soon)


## Notes

Add notes from the video (PRs are welcome)


<table>
   <tr>
      <td>⚠️</td>
      <td>
         The notes are written by the community. <br>
         If you see an error here, please create a PR with a fix.
      </td>
   </tr>
</table>


## Navigation

* [Machine Learning Zoomcamp course](../)
* [Session 11: KServe](./)
* Previous: [Deploying with KServe and EKS](07-kserve-eks.md)
* Next: [Explore more](09-explore-more.md)