
## 11.6 KServe transformers

<a href="https://www.youtube.com/watch?v=haowRqeAqJU&list=PL3MmuxUbc_hIhxl5Ji8t4O6lPAOpHaCLR"><img src="images/thumbnail-11-06.jpg"></a>
 




## Notes

Add notes from the video (PRs are welcome)


<table>
   <tr>
      <td>⚠️</td>
      <td>
         The notes are written by the community. <br>
         If you see an error here, please create a PR with a fix.
      </td>
   </tr>
</table>


## Navigation

* [Machine Learning Zoomcamp course](../)
* [Session 11: KServe](./)
* Previous: [Serving TensorFlow models with KServe](05-tensorflow-kserve.md)
* Next: [Deploying with KServe and EKS](07-kserve-eks.md)