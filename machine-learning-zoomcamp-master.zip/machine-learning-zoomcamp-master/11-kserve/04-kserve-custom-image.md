
## 11.4 Deploying custom Scikit-Learn images with KServe

<a href="https://www.youtube.com/watch?v=REGNWrHZiCw&list=PL3MmuxUbc_hIhxl5Ji8t4O6lPAOpHaCLR"><img src="images/thumbnail-11-04.jpg"></a>
 




## Notes

Add notes from the video (PRs are welcome)


<table>
   <tr>
      <td>⚠️</td>
      <td>
         The notes are written by the community. <br>
         If you see an error here, please create a PR with a fix.
      </td>
   </tr>
</table>


## Navigation

* [Machine Learning Zoomcamp course](../)
* [Session 11: KServe](./)
* Previous: [Deploying a Scikit-Learn model with KServe](03-kserve-sklearn.md)
* Next: [Serving TensorFlow models with KServe](05-tensorflow-kserve.md)