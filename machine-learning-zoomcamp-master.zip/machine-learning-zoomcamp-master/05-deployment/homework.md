## Homework

* For 2023 cohort homework, check [the 2023 cohort folder](../cohorts/2023/)
* For 2022 cohort homework, check [the 2022 cohort folder](../cohorts/2022/)
* For 2021 cohort homework and solution, check [the 2021 cohort folder](../cohorts/2021/05-deployment/)


## Navigation

* [Machine Learning Zoomcamp course](../)
* [Session 5: Deploying Machine Learning Models](./)
* Previous: [Explore more](09-explore-more.md)
