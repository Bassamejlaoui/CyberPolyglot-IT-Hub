## Homework

* For 2023 cohort homework, check [the 2023 cohort folder](../cohorts/2023/)
* For 2022 cohort homework, check [the 2022 cohort folder](../cohorts/2022/)
* For 2021 cohort homework and solution, check [the 2021 cohort folder](../cohorts/2021/09-serverless/)


## Navigation

* [Machine Learning Zoomcamp course](../)
* [Session 9: Serverless Deep Learning](./)
* Previous: [Explore more](09-explore-more.md)