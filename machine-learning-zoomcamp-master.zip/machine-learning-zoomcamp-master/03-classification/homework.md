## Homework

* For 2023 cohort homework, check [the 2023 cohort folder](../cohorts/2023/03-classification/homework.md)
* For 2022 cohort homework, check [the 2022 cohort folder](../cohorts/2022/03-classification/homework.md)
* For 2021 cohort homework and solution, check [the 2021 cohort folder](../cohorts/2021/03-classification/)


## Navigation

* [Machine Learning Zoomcamp course](../)
* [Session 3: Machine Learning for Classification](./)
* Previous: [Explore more](14-explore-more.md)
