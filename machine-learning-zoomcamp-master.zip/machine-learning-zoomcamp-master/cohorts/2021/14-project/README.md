## 14. Third project

The requirements are the same as for the [capstone project](../12-capstone/)


* Submit your project [here](https://forms.gle/2V2qyDKeUhGwnfn4A)
  * Deadline: January 26, 23:00 CET
* Evaluate your peers
  * Project evaluation assingment: [here](https://docs.google.com/spreadsheets/d/e/2PACX-1vSXSWfDcoeefJZbt4anSRZQVuDGzkij8eiSdWoCRD3GbKSAYj-6BSA5X9M0w5CstxtMXU2jjuTtWr_v/pubhtml)
  * Submit the results [here](https://forms.gle/WYAcXaawfcpGtZGD7) 
  * Deadline: February 2, 22:00 CET

