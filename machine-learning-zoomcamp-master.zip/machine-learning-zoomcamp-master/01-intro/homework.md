## Homework

* For 2023 cohort homework, check [the 2023 cohort folder](../cohorts/2023/01-intro/homework.md)
* For 2022 cohort homework, check [the 2022 cohort folder](../cohorts/2022/01-intro/homework.md)
* For 2021 cohort homework and solution, check [the 2021 cohort folder](../cohorts/2021/01-intro/)


## Navigation

* [Machine Learning Zoomcamp course](../)
* [Lesson 1: Introduction to Machine Learning](./)
* Previous: [Summary](10-summary.md)
