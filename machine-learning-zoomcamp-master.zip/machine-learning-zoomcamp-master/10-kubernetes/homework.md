## Homework

* For 2023 cohort homework, check [the 2023 cohort folder](../cohorts/2023/)
* For 2022 cohort homework, check [the 2022 cohort folder](../cohorts/2022/)
* For 2021 cohort homework and solution, check [the 2021 cohort folder](../cohorts/2021/10-kubernetes/)


## Navigation

* [Machine Learning Zoomcamp course](../)
* [Session 10: Kubernetes and TensorFlow Serving](./)
* Previous: [Explore more](10-explore-more.md)