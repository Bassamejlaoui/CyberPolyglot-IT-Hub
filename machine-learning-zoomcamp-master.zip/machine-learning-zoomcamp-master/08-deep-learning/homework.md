## Homework
* For 2023 cohort homework, check [the 2023 cohort folder](../cohorts/2023/08-deep-learning/)
* For 2022 cohort homework, check [the 2022 cohort folder](../cohorts/2022/)
* For 2021 cohort homework and solution, check [the 2021 cohort folder](../cohorts/2021/08-deep-learning/)


## Navigation

* [Machine Learning Zoomcamp course](../)
* [Session 8: Neural Networks and Deep Learning](./)
* Previous: [Explore more](14-explore-more.md)
