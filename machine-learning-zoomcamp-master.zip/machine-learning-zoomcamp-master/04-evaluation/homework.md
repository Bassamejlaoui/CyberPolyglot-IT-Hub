## Homework

* For 2023 cohort homework, check [the 2023 cohort folder](../cohorts/2023/04-evaluation/homework.md)
* For 2022 cohort homework, check [the 2022 cohort folder](../cohorts/2022/04-evaluation/homework.md)
* For 2021 cohort homework and solution, check [the 2021 cohort folder](../cohorts/2021/04-evaluation/)


## Navigation

* [Machine Learning Zoomcamp course](../)
* [Session 4: Evaluation Metrics for Classification](./)
* Previous: [Explore more](09-explore-more.md)