## Homework

* For 2023 cohort homework, check [the 2023 cohort folder](../cohorts/2023/02-regression/homework.md)
* For 2022 cohort homework, check [the 2022 cohort folder](../cohorts/2022/02-regression/homework.md)
* For 2021 cohort homework and solution, check [the 2021 cohort folder](../cohorts/2021/02-regression/)


## Navigation

* [Machine Learning Zoomcamp course](../)
* [Session 2: Machine Learning for Regression](./)
* Previous: [Explore more](17-explore-more.md)
